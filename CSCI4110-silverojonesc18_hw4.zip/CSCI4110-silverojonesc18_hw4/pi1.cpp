#include <iostream>
#include <chrono>
#include <cmath>
#include <mpi.h>

using namespace std;

// Function to calculate PI
long double calcPI(long double PI, long double n, long double sign, long double iterations)
{
    // Add for (iterations)
    for (unsigned long int i = 0; i <= iterations; i++) {
        PI = PI + (sign * (4 / ((n) * (n + 1) * (n + 2))));
        // Add and sub
        // alt sequences
        sign = sign * (-1);
        // Increment by 2 according to Nilkantha’s formula
        n += 2;
    }

    // Return the value of Pi
    return PI;
}

int main(int argc, char** argv) {
    MPI_Init(&argc, &argv);

    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    const long double PI25DT = 3.141592653589793238462643383; // True value of pi

    if (argc != 2) {
        if (rank == 0) {
            cout << "Usage: " << argv[0] << " <iterations>" << endl;
        }
        MPI_Finalize();
        return 1;
    }

    long double iterations = stod(argv[1]);

    // Adjust chunk size based on the number of processors
    long double chunk_size = ceil(iterations / size);
    long double start = rank * chunk_size + 2; // Start iteration
    long double end = fmin((rank + 1) * chunk_size + 1, iterations); // End iteration

    auto start_time = chrono::steady_clock::now(); // Start time

    // Calculate local sum for each process
    long double local_sum = calcPI(0.0, start, 1.0, end - start); // Provide necessary arguments to calcPI

    // Use MPI_Sendrecv to exchange data between adjacent processes
    int dest = (rank + 1) % size;
    int source = (rank + size - 1) % size;
    long double recv_sum;
    MPI_Sendrecv(&local_sum, 1, MPI_LONG_DOUBLE, dest, 0,
                 &recv_sum, 1, MPI_LONG_DOUBLE, source, 0,
                 MPI_COMM_WORLD, MPI_STATUS_IGNORE);

    // Aggregate the received sum with the local sum
    long double global_sum = local_sum + recv_sum;

    // Print result only from rank 0
    if (rank == 0) {
        auto end_time = chrono::steady_clock::now(); // End time
        auto elapsed_time = chrono::duration<double>(end_time - start_time).count();

        cout << "PI is approximately " << global_sum << ", Error is " << fabsl(global_sum - PI25DT) << endl;
        cout << "Runtime: " << elapsed_time << " seconds" << endl;
    }

    MPI_Finalize();
    return 0;
}

