#include <iostream>
#include <chrono>
#include <cmath>
#include <omp.h>

using namespace std;

// Function to calculate PI
long double calcPI(long double PI, long double n_start, long double n_end, long double sign)
{
    for (unsigned long int n = n_start; n <= n_end; n++) {
        PI += (sign * (4 / ((n) * (n + 1) * (n + 2))));
        sign = -sign;
    }
    return PI;
}

int main(int argc, char** argv)
{
    // Initialise variables, require/accept passed-in value 
    auto start = chrono::steady_clock::now();  // set timer
    long double PI = 3, sign = 1;
    const long double PI25DT = 3.141592653589793238462643383; // set test value for error
    long double cPI = 0.0;

    if (argc == 1)
    {
        printf("You must pass a single numeric value\n");
        printf("the value should be 100M or higher\n");
        return -1;
    }

    long double iterations = stod(argv[1]); // set to passed-in numeric value

    #pragma omp parallel
    {
        int thread_id = omp_get_thread_num();
        int num_threads = omp_get_num_threads();

        long double n_start = 2 + (iterations / num_threads) * thread_id;
        long double n_end = 1 + (iterations / num_threads) * (thread_id + 1);
        if (thread_id == num_threads - 1)
            n_end = iterations;

        cPI = calcPI(cPI, n_start, n_end, sign);
    }

    // Function call
    printf("PI is approx %.50Lf, Error is %.50Lf\n", cPI, fabsl(cPI - PI25DT));
    auto end = chrono::steady_clock::now(); // end timer
    auto diff = end - start; // compute time
    cout << chrono::duration<double, std::milli>(diff).count() << " Runtime ms" << endl;

    return 0;
}

