#include <iostream>
#include <chrono>
#include <cmath>
#include <mpi.h>

using namespace std;

// Function to calculate PI
long double calcPI(long double PI, long double n, long double sign, long double iterations) {
    // Add for (iterations) 
    for (unsigned long int i = 0; i <= iterations; i++) {
        PI = PI + (sign * (4 / ((n) * (n + 1) * (n + 2))));
        // Add and sub
        // alt sequences
        sign = sign * (-1);
        // Increment by 2 according to Nilkantha’s formula
        n += 2;
    }
    return PI;
}

int main(int argc, char** argv) {
    MPI_Init(&argc, &argv);

    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    const long double PI25DT = 3.141592653589793238462643383; // True value of pi

    if (argc != 2) {
        if (rank == 0) {
            cout << "Usage: " << argv[0] << " <iterations>" << endl;
        }
        MPI_Finalize();
        return 1;
    }

    long double iterations = stod(argv[1]);

    // Perform calculation locally
    long double local_sum = calcPI(2 + rank, iterations, 1, iterations);

    // Allocate buffer for global sums
    long double* global_sums = new long double[size];

    // Create a shared memory window for global sums
    MPI_Win win;
    MPI_Win_allocate(sizeof(long double), sizeof(long double), MPI_INFO_NULL, MPI_COMM_WORLD, &global_sums, &win);

    // Accumulate local sum into global sums using one-sided communication
    MPI_Win_lock(MPI_LOCK_EXCLUSIVE, 0, 0, win);
    global_sums[0] = local_sum;
    MPI_Win_unlock(0, win);

    // Synchronize to ensure all processes have written their local sum
    MPI_Barrier(MPI_COMM_WORLD);

auto start_time = chrono::steady_clock::now();

    // Perform reduction on global sums to get the final result
    long double global_sum = 0.0;
    for (int i = 0; i < size; i++) {
        global_sum += global_sums[i];
    }

    // Free the window and release resources
    MPI_Win_free(&win);
    delete[] global_sums;

    if (rank == 0) {
        auto end_time = chrono::steady_clock::now(); // End time
        auto elapsed_time = chrono::duration<double>(end_time - start_time).count();

        cout << "PI is approximately " << global_sum << ", Error is " << fabsl(global_sum - PI25DT) << endl;
        cout << "Runtime: " << elapsed_time << " seconds" << endl;
    }

    MPI_Finalize();
    return 0;
}

