#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>
#include "common.h"
#include "omp.h"

//
//  benchmarking program
//
int main( int argc, char **argv )
{   
    int navg, nabsavg=0, numthreads; // Declare variables for average number of interactions and number of threads
    double dmin, absmin=1.0, davg, absavg=0.0; // Declare variables for minimum distance and average force

    if( find_option( argc, argv, "-h" ) >= 0 )
    {
        printf( "Options:\n" );
        printf( "-h to see this help\n" );
        printf( "-n <int> to set number of particles\n" );
        printf( "-o <filename> to specify the output file name\n" );
        printf( "-s <filename> to specify a summary file name\n" ); 
        printf( "-no turns off all correctness checks and particle output\n");   
        return 0;
    }

    int n = read_int( argc, argv, "-n", 1000 ); // Read number of particles
    char *savename = read_string( argc, argv, "-o", NULL ); // Read output file name
    char *sumname = read_string( argc, argv, "-s", NULL ); // Read summary file name

    FILE *fsave = savename ? fopen( savename, "w" ) : NULL; // Open output file for writing
    FILE *fsum = sumname ? fopen ( sumname, "a" ) : NULL; // Open summary file for appending      

    particle_t *particles = (particle_t*) malloc( n * sizeof(particle_t) ); // Allocate memory for particles
    set_size( n ); // Set size of simulation space
    init_particles( n, particles ); // Initialize particle positions and velocities

    //
    //  simulate a number of time steps
    //
    double simulation_time = read_timer( );

    int local_navg = 0; // Local variables for each thread
    double local_davg = 0.0;
    double local_dmin = 1.0;
    

    #pragma omp parallel private(dmin, numthreads) // Start parallel region
    {
        numthreads = omp_get_num_threads(); // Get total number of threads
        for( int step = 0; step < 1000; step++ ) // Loop over time steps
        {
            local_navg = 0; // Initialize local variables
            local_davg = 0.0;
         
            //
            //  compute all forces
            //
            #pragma omp for reduction(+:local_navg, local_davg) schedule(dynamic) // Parallelize force calculation loop
            for( int i = 0; i < n; i++ ) // Loop over particles
            {
                particles[i].ax = particles[i].ay = 0; // Reset acceleration
                for (int j = 0; j < n; j++ ) // Loop over other particles
                    apply_force( particles[i], particles[j], &local_dmin, &local_davg, &local_navg); // Apply force between particles
            }
            
            //
            //  move particles
            //
            #pragma omp for schedule(dynamic) // Parallelize particle movement loop
            for( int i = 0; i < n; i++ ) // Loop over particles
                move( particles[i] ); // Move particle
            
            if( find_option( argc, argv, "-no" ) == -1 ) // Check if output is enabled
            {
                //
                //  compute statistical data
                //
                if (local_navg) { // If local average is non-zero
                    #pragma omp atomic // Use atomic operation for updating shared variable
                    absavg += local_davg / local_navg; // Update global average force
                    #pragma omp atomic
                    nabsavg++; // Increment global count of average calculations
                }

                #pragma omp critical // Enter critical section for updating shared variables
                if (local_dmin < absmin) // If local minimum distance is less than global minimum
                    absmin = local_dmin; // Update global minimum distance

                //
                //  save if necessary
                //
                #pragma omp master // Execute following block of code only by the master thread
                if( fsave && (step % SAVEFREQ) == 0 ) // Check if saving is required at this step
                    save( fsave, n, particles ); // Save particle positions to file
            }
        }
    }

    simulation_time = read_timer( ) - simulation_time; // Calculate simulation time
    
    printf( "n = %d, threads = %d, simulation time = %g seconds", n, numthreads, simulation_time ); // Print simulation information

    if( find_option( argc, argv, "-no" ) == -1 ) // Check if output is enabled
    {
        if (nabsavg) absavg /= nabsavg; // Calculate average force if valid
        printf( ", absmin = %lf, absavg = %lf", absmin, absavg ); // Print
