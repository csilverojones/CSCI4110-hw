module unload intel
module load gcc
module load openmpi/4.1.1-gcc8.3.1
